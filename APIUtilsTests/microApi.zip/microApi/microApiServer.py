from bottle import route,run,template
from time import sleep
import random

@route('/hello/world')
def helloWorld():
	return {"text":"Hello world","number":5}

@route('/never/returns')
def neverReturns():
	#just wait for a bit
	sleep(5)
	#return {"text":"Hello world","number":5}

@route('/sometimes/returns')
def neverReturns():
	if random.randint(0,10)>8:
		print("returns")
		return {"text":"Hello world","number":5}
	else:
		print("don't returns")



run(host='localhost', port=7080, debug=True)